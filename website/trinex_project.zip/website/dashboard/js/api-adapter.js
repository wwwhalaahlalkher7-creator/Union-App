window.Adapter = (() => {
  const base=()=>window.APP_CONFIG.api.baseUrl.replace(/\/$/,'');
  const token=()=>{try{return Auth.get()?.token||'';}catch{return '';}};
  async function req(path, options={}){
    const headers={'Content-Type':'application/json',...(options.headers||{})}; if(token()) headers.Authorization='Bearer '+token();
    const r=await fetch(base()+path,{...options,headers}); let d=null; try{d=await r.json();}catch{}
    if(!r.ok||d?.success===false) throw new Error(d?.error?.message||d?.error||'تعذّر تنفيذ الطلب');
    return d?.data ?? d;
  }
  const schemas={
    news:{label:'خبر',labelPlural:'الأخبار',dateField:'Date',fields:[{key:'Title',label:'العنوان',type:'text',required:true},{key:'Content',label:'المحتوى',type:'textarea',required:true},{key:'Category',label:'التصنيف',type:'select',options:['إعلان هام','بيان رسمي','تغطية إعلامية','نشاط أكاديمي'],default:'إعلان هام'},{key:'Publisher',label:'الناشر',type:'text',default:'أمانة الإعلام'},{key:'Date',label:'تاريخ النشر',type:'date'},{key:'Image',label:'صورة',type:'image'}]},
    announcements:{label:'إشعار',labelPlural:'الإشعارات',dateField:'Date',fields:[{key:'Title',label:'العنوان',type:'text',required:true},{key:'Content',label:'النص',type:'textarea',required:true},{key:'Type',label:'النوع',type:'select',options:[{value:'general',label:'عام'},{value:'urgent',label:'عاجل'},{value:'academic',label:'أكاديمي'},{value:'administrative',label:'إداري'}],default:'general'},{key:'DepartmentId',label:'معرّف القسم (اختياري)',type:'text'},{key:'SemesterId',label:'معرّف الفصل (اختياري)',type:'text'},{key:'Date',label:'وقت النشر',type:'datetime-local'},{key:'ExpiresAt',label:'وقت الانتهاء',type:'datetime-local'}]},
    achievements:{label:'إنجاز',labelPlural:'الإنجازات',dateField:'PublishDate',fields:[{key:'Title',label:'العنوان',type:'text',required:true},{key:'Intro',label:'المقدمة',type:'textarea'},{key:'HighlightsTitle',label:'عنوان المحاور',type:'text',default:'أبرز المحاور'},{key:'Highlights',label:'المحاور',type:'textarea'},{key:'Badge',label:'التصنيف',type:'text'},{key:'Publisher',label:'الناشر',type:'text',default:'أمانة الإعلام'},{key:'PublishDate',label:'تاريخ النشر',type:'date'},{key:'Image',label:'الصور',type:'images'}]},
    activities:{label:'نشاط',labelPlural:'الأنشطة',dateField:'Date',fields:[{key:'Title',label:'العنوان',type:'text',required:true},{key:'Content',label:'الوصف',type:'textarea',required:true},{key:'Location',label:'الموقع',type:'text'},{key:'Publisher',label:'الناشر',type:'text',default:'أمانة الإعلام'},{key:'Date',label:'تاريخ البداية',type:'date',required:true},{key:'EndDate',label:'تاريخ الانتهاء',type:'date'},{key:'Image',label:'صورة',type:'image'}]}
  };
  function parseJsonArray(value){if(!value)return[];if(Array.isArray(value))return value;try{const parsed=JSON.parse(value);return Array.isArray(parsed)?parsed:[];}catch{return[];}}
  function rowContent(type,r){
    const x={id:r.id,createdTime:r.created_at,fields:{Status:r.status||'draft'}};
    if(type==='news')Object.assign(x.fields,{Title:r.title||'',Content:r.body||'',Category:r.category||'إعلان هام',Publisher:r.publisher||'أمانة الإعلام',Date:r.publish_at||'',Image:r.image_url||'',Views:0,Hearts:0});
    if(type==='activities')Object.assign(x.fields,{Title:r.title||'',Content:r.body||'',Location:r.location||'',Publisher:r.publisher||'أمانة الإعلام',Date:r.event_at||'',EndDate:r.end_at||'',Image:r.image_url||'',Views:0,Hearts:0});
    if(type==='announcements')Object.assign(x.fields,{Title:r.title||'',Content:r.body||'',Type:r.type||'general',DepartmentId:r.target_department_id||'',SemesterId:r.target_semester_id||'',Date:r.publish_at||'',ExpiresAt:r.expires_at||''});
    if(type==='achievements')Object.assign(x.fields,{Title:r.title||'',Intro:r.intro||r.description||'',HighlightsTitle:r.highlights_title||'أبرز المحاور',Highlights:parseJsonArray(r.highlights).join('\n'),Badge:r.badge||'',Publisher:r.publisher||'أمانة الإعلام',PublishDate:r.achieved_at||'',Image:parseJsonArray(r.images_json).map(url=>({url:String(url)})),Views:0,Hearts:0});
    return x;
  }
  function contentPayload(type,f){
    const status=['draft','published','archived'].includes(String(f.Status||''))?String(f.Status):'published';
    const o={title:f.Title||'',body:f.Content||f.Intro||'',description:f.Intro||'',status};
    if(type==='news')Object.assign(o,{publish_at:f.Date||null,category:f.Category||null,publisher:f.Publisher||null,...(f.Image !== undefined ? {image_url:Array.isArray(f.Image)?(f.Image[0]?.url||f.Image[0]||null):(f.Image||null)} : {})});
    if(type==='activities')Object.assign(o,{event_at:f.Date||null,end_at:f.EndDate||null,location:f.Location||null,publisher:f.Publisher||null,...(f.Image !== undefined ? {image_url:Array.isArray(f.Image)?(f.Image[0]?.url||f.Image[0]||null):(f.Image||null)} : {})});
    if(type==='announcements')Object.assign(o,{type:f.Type||'general',target_department_id:f.DepartmentId||null,target_semester_id:f.SemesterId||null,publish_at:f.Date||null,expires_at:f.ExpiresAt||null});
    if(type==='achievements')Object.assign(o,{achieved_at:f.PublishDate||null,intro:f.Intro||null,highlights_title:f.HighlightsTitle||null,highlights:f.Highlights?JSON.stringify(String(f.Highlights).split(/\r?\n/).map(x=>x.trim()).filter(Boolean)):null,badge:f.Badge||null,publisher:f.Publisher||null,images_json:Array.isArray(f.Image)?JSON.stringify(f.Image.map(x=>x?.url||x).filter(Boolean)):null});
    return o;
  }
  async function listContent(type){const rows=await req('/admin/'+type+'?limit=100');return rows.map(r=>rowContent(type,r));}
  async function createContent(type,fields){return req('/admin/'+type,{method:'POST',body:JSON.stringify(contentPayload(type,fields))});}
  async function updateContent(type,id,fields){return req('/admin/'+type+'/'+encodeURIComponent(id),{method:'PATCH',body:JSON.stringify(contentPayload(type,fields))});}
  async function deleteContent(type,id){return req('/admin/'+type+'/'+encodeURIComponent(id),{method:'DELETE'});} async function sendNotification(announcementId){return req('/admin/notifications/send',{method:'POST',body:JSON.stringify({announcementId})});} async function listNotifications(){return req('/admin/notifications?limit=100');}
  async function listStudentsAdmin(filters={}){
    const q=new URLSearchParams({limit:'100'});if(filters.q)q.set('q',filters.q);
    const rows=await req('/admin/students?'+q);
    const [departments,semesters]=await Promise.all([req('/departments'),req('/semesters')]);
    const depMap=new Map(departments.map(d=>[d.id,d]));
    const semMap=new Map(semesters.map(s=>[s.id,s]));
    return {records:rows.map(r=>{
      const dep=depMap.get(r.department_id), sem=semMap.get(r.current_semester_id);
      return {id:r.id,studentId:r.student_number,name:r.full_name,department:r.department_id,departmentName:dep?.name_ar||dep?.name_en||dep?.code||r.department_id,semester:r.current_semester_id,semesterName:sem?.name_ar||sem?.name_en||(sem?.number!=null?`الفصل ${sem.number}`:r.current_semester_id),active:!!r.active,fields:{Student:r.full_name,Student_ID:r.student_number,Department:r.department_id,Semester:r.current_semester_id,Active:r.active}};
    }),departments,semesters};
  }
  async function createStudentAdmin(s){return req('/admin/students',{method:'POST',body:JSON.stringify({student_number:String(s.Student_ID||s.studentNumber||'').trim(),full_name:String(s.Student||s.fullName||'').trim(),department_id:s.Department||s.department_id,current_semester_id:s.Semester||s.current_semester_id,active:s.Active===false?0:1})});}
  async function updateStudentAdmin(id,s){return req('/admin/students/'+id,{method:'PATCH',body:JSON.stringify({student_number:String(s.Student_ID||s.studentNumber||'').trim(),full_name:String(s.Student||s.fullName||'').trim(),department_id:s.Department||s.department_id,current_semester_id:s.Semester||s.current_semester_id,active:s.Active===false?0:1})});}
  async function deleteStudentAdmin(id){return req('/admin/students/'+id,{method:'DELETE'});} async function toggleStudentAdmin(id,active){return req('/admin/students/'+id,{method:'PATCH',body:JSON.stringify({active:active?1:0})});}
  async function listScheduleAdmin(filters={}){const q=new URLSearchParams({limit:'100'});if(filters.departmentId)q.set('departmentId',filters.departmentId);if(filters.semester)q.set('semesterId',filters.semester);const rows=await req('/admin/schedule?'+q);const deps=await req('/departments'),sems=await req('/semesters'),subs=await req('/admin/subjects?limit=100');return {entries:rows.map(r=>({id:r.id,departmentId:r.department_id,semester:r.semester_id,dayOfWeek:r.day_of_week,startTime:r.start_time,endTime:r.end_time,subjectId:r.subject_id,subjectName:(subs.find(x=>x.id===r.subject_id)||{}).name_ar||'',room:r.room||'',instructor:r.lecturer||'',active:!!r.active})),departments:deps.map(d=>({id:d.id,name:{ar:d.name_ar,en:d.name_en}})),semesters:sems,subjects:subs};}
  async function scheduleMut(id,p){const body={semester_id:p.semester_id||p.semesterId||p.semester||'',department_id:p.department_id||p.departmentId||p.department||'',day_of_week:p.day_of_week??p.dayOfWeek,start_time:p.start_time||p.startTime||'',end_time:p.end_time||p.endTime||'',subject_id:p.subject_id||p.subjectId||null,room:p.room||'',lecturer:p.lecturer||p.instructor||'',active:p.active==null?1:(p.active?1:0)};return req('/admin/schedule'+(id?'/'+id:''),{method:id?'PATCH':'POST',body:JSON.stringify(body)});} async function createScheduleEntry(e){return scheduleMut(null,e);} async function updateScheduleEntry(id,e){return scheduleMut(id,e);} async function deleteScheduleEntry(id){return req('/admin/schedule/'+id,{method:'DELETE'});} async function toggleScheduleEntry(id,a){return scheduleMut(id,{active:a?1:0});}
  async function listMaterialsAdmin(){const rows=await req('/admin/materials?limit=100');const subjects=await req('/admin/subjects?limit=100');const deps=await req('/departments');const sems=await req('/semesters');const tree=deps.map(d=>({id:d.id,name:d.name_ar,semesters:sems.map(se=>({id:se.id,name:se.name_ar,subjects:subjects.filter(s=>s.department_id===d.id&&s.semester_id===se.id).map(s=>({id:s.id,name:s.name_ar,files:rows.filter(m=>m.subject_id===s.id).map(m=>({id:m.id,name:m.title,link:m.drive_web_view_url||m.drive_url||'#'}))}))})).filter(x=>x.subjects.length||rows.some(m=>subjects.some(s=>s.id===m.subject_id&&s.department_id===d.id&&s.semester_id===x.id)))}));return {tree};}
  async function createMaterialFolder(semesterId,name,departmentId){const subjects=await req('/admin/subjects?limit=100');const dep=departmentId||subjects.find(x=>x.semester_id===semesterId)?.department_id;if(!dep)throw new Error('اختر القسم أولاً.');return req('/admin/subjects',{method:'POST',body:JSON.stringify({semester_id:semesterId,department_id:dep,name_ar:name,name_en:name,active:1,sort_order:0})});}
  async function renameMaterialItem(){throw new Error('تعديل ملفات Drive المباشر غير مفعّل في هذه المرحلة. استخدم المزامنة الآمنة.');} async function deleteMaterialItem(id){return req('/admin/materials/'+id,{method:'DELETE'});} async function deleteSubject(id){return req('/admin/subjects/'+id,{method:'DELETE'});} async function uploadMaterialPdf(){throw new Error('رفع ملفات Drive المباشر غير مفعّل في هذه المرحلة.');}
  async function getSiteSettings(){const rows=await req('/admin/settings');const o={};for(const r of rows){try{o[r.key]=JSON.parse(r.value_json);}catch{o[r.key]=r.value_json;}}return o;}
  async function updateSiteSettings(fields){for(const [key,value] of Object.entries(fields||{}))await req('/admin/settings/'+encodeURIComponent(key),{method:'PATCH',body:JSON.stringify({key,value})});return {success:true};}
  async function listUsers(){return (await req('/admin/staff')).map(r=>({id:r.id,fields:{Names:r.display_name,Username:r.user_id,Email:r.email||'',Role:roleLabel(r.role_id),RoleId:r.role_id,Active:!!r.active,LastLogin:r.last_login_at}}));}
  const ROLE_IDS={
    'مدير عام':'super_admin',
    'محرر محتوى':'content_manager',
    'مسؤول أكاديمي':'academic_manager',
    super_admin:'super_admin',content_manager:'content_manager',academic_manager:'academic_manager',moderator:'moderator', 'مشرف':'moderator'
  };
  const ROLE_BADGE={super_admin:'badge-danger',content_manager:'badge-info',academic_manager:'badge-success',moderator:'badge-warning'};
  const ROLE_LABEL={super_admin:'مدير عام',content_manager:'محرر محتوى',academic_manager:'مسؤول أكاديمي',moderator:'مشرف'};
  function roleId(value){return ROLE_IDS[value]||value||'content_manager';}
  function roleLabel(value){return ROLE_LABEL[value]||value||'—';}
  async function createUser(f){return req('/admin/staff',{method:'POST',body:JSON.stringify({userId:f.Username, email:f.Email||null, displayName:f.Names,roleId:roleId(f.Role),password:f.Password})});}
  async function updateUser(id,f){return req('/admin/staff/'+id,{method:'PATCH',body:JSON.stringify({userId:f.Username, email:f.Email===undefined?undefined:(f.Email||null),displayName:f.Names,roleId:roleId(f.Role),active:f.Active,password:f.Password||undefined})});}
  async function toggleUserActive(id){const users=await listUsers(),u=users.find(x=>x.id===id);return updateUser(id,{Names:u.fields.Names,Username:u.fields.Username,Role:u.fields.RoleId||u.fields.Role,Active:!u.fields.Active});} async function deleteUser(id){return req('/admin/staff/'+id,{method:'DELETE'});}
  async function listModerationComments(status='visible'){return req('/admin/moderation/comments?status='+encodeURIComponent(status)+'&limit=100');}
  async function moderateComment(id,status){return req('/admin/moderation/comments/'+encodeURIComponent(id),{method:'PATCH',body:JSON.stringify({status})});} async function deleteCommentAdmin(id){return req('/admin/comments/'+encodeURIComponent(id),{method:'DELETE'});}
  async function listAuditLog(){return (await req('/admin/audit-logs')).map(r=>({id:r.id,fields:{Timestamp:r.created_at,User:r.actor_name||r.actor_id||'',Role:r.role_name||'',Action:r.action,Details:r.resource_type+(r.resource_id?': '+r.resource_id:'')}}));}
  async function listFailedLoginAttempts(){return (await req('/admin/security/auth-events?limit=50')).map(r=>({id:r.id,fields:{Timestamp:r.created_at,User:r.actor_name||r.actor_user_id||r.actor_email||r.actor_id||'',Role:r.role_name||'',Action:r.event_type,Details:r.event_type}}));}
  async function changePassword(oldPassword,newPassword){return req('/auth/staff/change-password',{method:'POST',body:JSON.stringify({currentPassword:oldPassword,newPassword})});}
  async function login(userId,password){const d=await req('/auth/staff/login',{method:'POST',headers:{},body:JSON.stringify({userId,password})});return {token:d.token,refreshToken:d.refreshToken,name:d.staffDisplayName||userId,role:d.staffRole||d.role_name||d.staffRoleId,expiresAt:Date.now()+((d.expiresInSeconds||900)*1000)};}
  async function logoutSession(t){try{await fetch(base()+'/auth/logout',{method:'POST',headers:{Authorization:'Bearer '+t}});}catch{}}
  async function getOverviewStats(){return req('/admin/dashboard/overview');}
  async function getEinoUsage(hours=24){return req('/admin/security/eino-usage?hours='+encodeURIComponent(Math.min(168,Math.max(1,Number(hours)||24))));} async function getRecentNews(l){return (await listContent('news')).slice(0,l||5).map(r=>({id:r.id,title:r.fields.Title,date:r.fields.Date,views:0}));} async function getSystemHealth(){try{await req('/health');return [{name:'Association API',configured:true,lastSuccess:new Date().toISOString()}];}catch{return [{name:'Association API',configured:true,lastSuccess:null}];}}
  return {CONTENT_TYPES:schemas,getContentSchema:t=>schemas[t],listContent,createContent,updateContent,deleteContent,listStudentsAdmin,createStudentAdmin,updateStudentAdmin,deleteStudentAdmin,toggleStudentAdmin,listScheduleAdmin,createScheduleEntry,updateScheduleEntry,deleteScheduleEntry,toggleScheduleEntry,listMaterialsAdmin,createMaterialFolder,renameMaterialItem,deleteMaterialItem,deleteSubject,uploadMaterialPdf,getSiteSettings,updateSiteSettings,listUsers,createUser,updateUser,toggleUserActive,deleteUser,listAuditLog,listFailedLoginAttempts,listModerationComments,moderateComment,deleteCommentAdmin,changePassword,login,logoutSession,getOverviewStats,getEinoUsage,getRecentNews,getSystemHealth,sendNotification,listNotifications,ROLE_BADGE};
})();
