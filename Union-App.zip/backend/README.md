# Backend

Cloudflare Worker + D1 API for the association application.

## Eino provider architecture

Eino is capability-first and routes each task through providers that explicitly advertise support for that capability.
Provider selection is handled by `src/providers/registry.js` and routes each
capability through providers that explicitly advertise support for it.

Current provider configuration:

- `mistral`: primary Text/Vision/OCR provider, with Mistral Small 4 (`mistral-small-2603`) for text/vision and Mistral OCR for documents.
- `groq`: primary STT/TTS provider, with Whisper Large V3 Turbo for transcription and Orpheus Arabic for Arabic speech generation; it is also a text/vision fallback.
- `free.ai`: optional final fallback for capabilities it supports.

Current capability chains:

- Text: Mistral Small 4 → Groq GPT-OSS 120B → Free.ai.
- Vision: Mistral Small 4 → Groq Qwen 3.8 27B → Free.ai.
- OCR: Mistral OCR → Free.ai.
- STT: Groq Whisper Large V3 Turbo → Mistral Voxtral Transcribe → Free.ai.
- TTS: Groq Orpheus Arabic → Mistral Voxtral TTS → Free.ai.

The router selects by capability first and only uses a fallback when the selected provider reports a retryable failure. Provider credentials are never sent to Flutter.

Embeddings remain separately configurable through `EINO_EMBEDDING_BASE_URL`, `EINO_EMBEDDING_API_KEY` and `EINO_EMBEDDING_MODEL`.

## Memory

Student-owned Eino memory is stored canonically in D1. Semantic indexing is
optional through Chroma and a separately configured embedding provider. If the
embedding/Chroma path is unavailable, Eino safely falls back to the D1 memory
records.

## Local environment

For local Worker secrets, copy `backend/.dev.vars.example` to `backend/.dev.vars` and replace the placeholders. The file is ignored by Git and must never contain values that are committed to the repository.

## Source layout

`src/index.js` هو router وWorker entry point فقط. منطق الـAPI موزع على modules بحسب النطاق:
`core.js`, `auth.js`, `public.js`, `student.js`, `academic.js`, `interactions.js`,
`media.js`, `admin.js`, `eino.js`, و`drive.js`.

عند إضافة endpoint جديد، سجّل route في `index.js` وضع handler في module مالك للنطاق.


## تكاملات Google Apps Script

يستخدم Worker مشروعين مستقلين تمامًا من Google Apps Script:
- **TRINEX Drive**: فهرسة المواد الدراسية وحذف ملفات Drive وتسجيل الفتحات.
- **TRINEX Gmail**: إرسال رسائل استعادة كلمة المرور، مع قابلية إضافة خدمات بريد مستقبلًا.

هذا الفصل مقصود حتى لا يؤثر تعطل البريد على Drive أو العكس.

### استعادة كلمة المرور

يضبط Worker:
- `GOOGLE_APPS_SCRIPT_GMAIL_URL` كرابط Web App لمشروع TRINEX Gmail، ويُحقن وقت النشر من GitHub Secret.
- `GOOGLE_APPS_SCRIPT_GMAIL_TOKEN` كـ secret، وتكون قيمته نفسها في Script Property باسم `EMAIL_API_TOKEN`.

رمز الاستعادة صالح لمدة 10 دقائق، ويُخزن في D1 كـ hash فقط، مع حد أقصى 5 محاولات. بعد نجاح الاستعادة تُبطل جلسات الطالب السابقة.

### المواد الدراسية

يضبط Worker:
- `GOOGLE_APPS_SCRIPT_DRIVE_URL` كرابط Web App لمشروع TRINEX Drive، ويُحقن وقت النشر من GitHub Secret.
- `GOOGLE_APPS_SCRIPT_DRIVE_TOKEN` كـ secret، وتكون قيمته نفسها في Script Property باسم `API_TOKEN`.

مشروع Drive يستخدم `ROOT_FOLDER_ID` للوصول إلى مجلد المواد، و`STATS_SHEET_ID` اختياري لإحصائيات فتح الملفات.
