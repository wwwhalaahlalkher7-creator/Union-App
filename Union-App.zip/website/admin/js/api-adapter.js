window.Adapter = (() => {
  const base=()=>window.APP_CONFIG.api.baseUrl.replace(/\/$/,'');
  const token=()=>{try{return Auth.get()?.token||'';}catch{return '';}};
  async function req(path, options={}){
    const headers={'Content-Type':'application/json',...(options.headers||{})}; if(token()) headers.Authorization='Bearer '+token();
    const r=await fetch(base()+path,{...options,headers}); let d=null; try{d=await r.json();}catch{}
    if(!r.ok||d?.success===false) { const detail=d?.error?.details||d?.error?.message||d?.error; throw new Error(typeof detail==='string'?detail:'تعذّر تنفيذ الطلب'); }
    return d?.data ?? d;
  }
  async function reqMultipart(path, formData){
    const headers={}; if(token()) headers.Authorization='Bearer '+token();
    const r=await fetch(base()+path,{method:'POST',body:formData,headers}); let d=null; try{d=await r.json();}catch{}
    if(!r.ok||d?.success===false) { const detail=d?.error?.details||d?.error?.message||d?.error; throw new Error(typeof detail==='string'?detail:'تعذّر رفع الوسيط'); }
    return d?.data ?? d;
  }
  async function uploadMediaFiles(files){
    const list=Array.from(files||[]).filter(Boolean);
    if(!list.length) return [];
    if(list.length>5) throw new Error('الحد الأقصى 5 صور في المحتوى الواحد.');
    const form=new FormData(); list.forEach(file=>form.append('file',file,file.name));
    const data=await reqMultipart('/admin/media',form);
    return Array.isArray(data?.items)?data.items:[];
  }
  async function uploadMedia(file){const items=await uploadMediaFiles([file]);return items[0];}
  async function prepareContentFields(fields){
    const out={...(fields||{})};
    const single=out._ImageFile;
    const multiple=out._ImagesFiles;
    delete out._ImageFile; delete out._ImagesFiles; delete out.ImageBase64; delete out.ImagesBase64;
    if(single){ const uploaded=await uploadMedia(single); out.Image=[{url:uploaded.url}]; }
    else if(Array.isArray(multiple) && multiple.length){
      const uploaded=await uploadMediaFiles(multiple.slice(0,5));
      out.Image=uploaded.map(x=>({url:x.url}));
    }
    return out;
  }
  function parseJsonArray(value){if(!value)return[];if(Array.isArray(value))return value;try{const parsed=JSON.parse(value);return Array.isArray(parsed)?parsed:[];}catch{return[];}}
  function rowContent(type,r){
    const x={id:r.id,createdTime:r.created_at,fields:{Status:r.status||'draft'}};
    if(type==='news')Object.assign(x.fields,{Title:r.title||'',Content:r.body||'',Category:r.category||'إعلان هام',Publisher:r.publisher||'أمانة الإعلام',Date:r.publish_at||'',Image:r.images_json?parseJsonArray(r.images_json).map(url=>({url:String(url)})):(r.image_url?[{url:r.image_url}]:[]),Views:0,Hearts:0});
    if(type==='events')Object.assign(x.fields,{Title:r.title||'',Content:r.body||'',Category:r.category||'',Location:r.location||'',Publisher:r.publisher||'أمانة الإعلام',Date:r.event_at||'',EndDate:r.end_at||'',Image:r.images_json?parseJsonArray(r.images_json).map(url=>({url:String(url)})):(r.image_url?[{url:r.image_url}]:[]),Views:0,Hearts:0});
    if(type==='announcements')Object.assign(x.fields,{Title:r.title||'',Content:r.body||'',Type:r.type||'general',DepartmentId:r.target_department_id||'',SemesterId:r.target_semester_id||'',Date:r.publish_at||'',ExpiresAt:r.expires_at||''});
    if(type==='achievements')Object.assign(x.fields,{Title:r.title||'',Intro:r.intro||r.description||'',HighlightsTitle:r.highlights_title||'أبرز المحاور',Highlights:parseJsonArray(r.highlights).join('\n'),Badge:r.badge||'',Publisher:r.publisher||'أمانة الإعلام',PublishDate:r.achieved_at||'',Image:parseJsonArray(r.images_json).map(url=>({url:String(url)})),Views:0,Hearts:0});
    return x;
  }
  function contentPayload(type,f){
    const status=['draft','published'].includes(String(f.Status||''))?String(f.Status):'published';
    const o={title:f.Title||'',body:f.Content||f.Intro||'',description:f.Intro||'',status};
    if(type==='news')Object.assign(o,{publish_at:f.Date||null,category:f.Category||null,publisher:f.Publisher||null,...(f.Image !== undefined ? {image_url:Array.isArray(f.Image)?(f.Image[0]?.url||f.Image[0]||null):(f.Image||null),images_json:Array.isArray(f.Image)?JSON.stringify(f.Image.map(x=>x?.url||x).filter(Boolean)):null} : {})});
    if(type==='events')Object.assign(o,{category:f.Category||null,event_at:f.Date||null,end_at:f.EndDate||null,location:f.Location||null,publisher:f.Publisher||null,...(f.Image !== undefined ? {image_url:Array.isArray(f.Image)?(f.Image[0]?.url||f.Image[0]||null):(f.Image||null),images_json:Array.isArray(f.Image)?JSON.stringify(f.Image.map(x=>x?.url||x).filter(Boolean)):null} : {})});
    if(type==='announcements')Object.assign(o,{type:f.Type||'general',target_department_id:f.DepartmentId||null,target_semester_id:f.SemesterId||null,publish_at:f.Date||null,expires_at:f.ExpiresAt||null});
    if(type==='achievements')Object.assign(o,{achieved_at:f.PublishDate||null,intro:f.Intro||null,highlights_title:f.HighlightsTitle||null,highlights:f.Highlights?JSON.stringify(String(f.Highlights).split(/\r?\n/).map(x=>x.trim()).filter(Boolean)):null,badge:f.Badge||null,publisher:f.Publisher||null,images_json:Array.isArray(f.Image)?JSON.stringify(f.Image.map(x=>x?.url||x).filter(Boolean)):null});
    return o;
  }
  async function listContent(type){const rows=await req('/admin/'+type+'?limit=100');return rows.map(r=>rowContent(type,r));}
  async function createContent(type,fields){const prepared=await prepareContentFields(fields);return req('/admin/'+type,{method:'POST',body:JSON.stringify(contentPayload(type,prepared))});}
  async function updateContent(type,id,fields){const prepared=await prepareContentFields(fields);return req('/admin/'+type+'/'+encodeURIComponent(id),{method:'PATCH',body:JSON.stringify(contentPayload(type,prepared))});}
  async function deleteContent(type,id){return req('/admin/'+type+'/'+encodeURIComponent(id),{method:'DELETE'});} async function sendNotification(announcementId){return req('/admin/notifications/send',{method:'POST',body:JSON.stringify({announcementId})});} async function listNotifications(){return req('/admin/notifications?limit=100');}
  const asArray = value => Array.isArray(value) ? value : (Array.isArray(value?.items) ? value.items : (Array.isArray(value?.rows) ? value.rows : (Array.isArray(value?.data) ? value.data : [])));
  async function listStudentsAdmin(filters={}){
    const q=new URLSearchParams({limit:'100'});if(filters.q)q.set('q',filters.q);if(filters.department)q.set('department',filters.department);if(filters.semester)q.set('semester',filters.semester);
    const rows=asArray(await req('/admin/students?'+q));
    const [departmentsRaw,semestersRaw]=await Promise.all([req('/departments'),req('/semesters')]);
    const departments=asArray(departmentsRaw), semesters=asArray(semestersRaw);
    const depMap=new Map(departments.map(d=>[d.id,d]));
    const semMap=new Map(semesters.map(s=>[s.id,s]));
    return {records:rows.map(r=>{
      const dep=depMap.get(r.department_id), sem=semMap.get(r.current_semester_id);
      return {id:r.id,studentId:r.student_number,name:r.full_name,email:r.email||'',department:r.department_id,departmentName:dep?.name_ar||dep?.name_en||dep?.code||r.department_id,semester:r.current_semester_id,semesterName:sem?.name_ar||sem?.name_en||(sem?.number!=null?`الفصل ${sem.number}`:r.current_semester_id),active:!!r.active,registered:Number(r.registered||0)===1,fields:{Student:r.full_name,Student_ID:r.student_number,Email:r.email||'',Department:r.department_id,Semester:r.current_semester_id,Active:r.active}};
    }),departments,semesters};
  }
  function studentPayload(s){
    const studentNumber=String(s?.Student_ID??s?.studentNumber??s?.studentId??s?.student_id??'').trim();
    const fullName=String(s?.Student??s?.fullName??s?.name??s?.studentName??'').trim();
    const departmentId=String(s?.Department??s?.department_id??s?.departmentId??s?.department??'').trim();
    const semesterId=String(s?.Semester??s?.current_semester_id??s?.currentSemesterId??s?.semesterId??s?.semester??'').trim();
    const hasEmail=Object.prototype.hasOwnProperty.call(s||{},'email')||Object.prototype.hasOwnProperty.call(s||{},'Email');
    const email=String(s?.Email??s?.email??'').trim();
    if(!studentNumber||!fullName||!departmentId) throw new Error('بيانات الطالب الأساسية مطلوبة: الرقم الجامعي والاسم والقسم.');
    return {student_number:studentNumber,full_name:fullName,department_id:departmentId,...(hasEmail?{email:email||null}:{}),...(Object.prototype.hasOwnProperty.call(s||{},'semester')||Object.prototype.hasOwnProperty.call(s||{},'Semester')||Object.prototype.hasOwnProperty.call(s||{},'semesterId')||Object.prototype.hasOwnProperty.call(s||{},'current_semester_id')?{current_semester_id:semesterId||null}:{}),active:s?.Active===false?0:1};
  }
  async function createStudentAdmin(s){return req('/admin/students',{method:'POST',body:JSON.stringify(studentPayload(s))});}
  async function updateStudentAdmin(id,s){return req('/admin/students/'+id,{method:'PATCH',body:JSON.stringify(studentPayload(s))});}
  async function deleteStudentAdmin(id){return req('/admin/students/'+id,{method:'DELETE'});} async function toggleStudentAdmin(id,active){return req('/admin/students/'+id,{method:'PATCH',body:JSON.stringify({active:active?1:0})});}
  async function listScheduleAdmin(filters={}){const q=new URLSearchParams({limit:'100'});if(filters.departmentId)q.set('departmentId',filters.departmentId);if(filters.semester)q.set('semesterId',filters.semester);const [rowsRaw,depsRaw,semsRaw,subsRaw]=await Promise.all([req('/admin/schedule?'+q),req('/departments'),req('/semesters'),req('/admin/subjects?limit=100')]);const rows=asArray(rowsRaw),deps=asArray(depsRaw),sems=asArray(semsRaw),subs=asArray(subsRaw);return {entries:rows.map(r=>({id:r.id,departmentId:r.department_id,semester:r.semester_id,dayOfWeek:r.day_of_week,startTime:r.start_time,endTime:r.end_time,subjectId:r.subject_id,subjectName:(subs.find(x=>x.id===r.subject_id)||{}).name_ar||'',room:r.room||'',instructor:r.lecturer||'',active:!!r.active})),departments:deps.map(d=>({id:d.id,name:{ar:d.name_ar,en:d.name_en}})),semesters:sems,subjects:subs};}
  async function scheduleMut(id,p){const body={semester_id:p.semester_id||p.semesterId||p.semester||'',department_id:p.department_id||p.departmentId||p.department||'',day_of_week:p.day_of_week??p.dayOfWeek,start_time:p.start_time||p.startTime||'',end_time:p.end_time||p.endTime||'',subject_id:p.subject_id||p.subjectId||'',room:p.room||'',lecturer:p.lecturer||p.instructor||'',active:p.active==null?1:(p.active?1:0)};return req('/admin/schedule'+(id?'/'+id:''),{method:id?'PATCH':'POST',body:JSON.stringify(body)});} async function createScheduleEntry(e){return scheduleMut(null,e);} async function updateScheduleEntry(id,e){return scheduleMut(id,e);} async function deleteScheduleEntry(id){return req('/admin/schedule/'+id,{method:'DELETE'});} async function toggleScheduleEntry(id,a){return scheduleMut(id,{active:a?1:0});}
  async function syncDriveMaterials(){return req('/admin/drive/sync?nocache=1',{method:'POST'});}
  async function listMaterialsAdmin(){const [rowsRaw,subjectsRaw,depsRaw,semsRaw]=await Promise.all([req('/admin/materials?limit=100'),req('/admin/subjects?limit=100'),req('/departments'),req('/semesters')]);const rows=asArray(rowsRaw),subjects=asArray(subjectsRaw),deps=asArray(depsRaw),sems=asArray(semsRaw);const tree=deps.filter(d=>d&&d.id).map(d=>({id:d.id,name:d.name_ar||d.name_en||d.code||d.id,semesters:sems.filter(se=>se&&se.id).map(se=>({id:se.id,name:se.name_ar||se.name_en||(`الفصل ${se.number??se.id}`),subjects:subjects.filter(s=>s.department_id===d.id&&s.semester_id===se.id).map(s=>({id:s.id,name:s.name_ar||s.name_en||s.code||s.id,files:rows.filter(m=>m.subject_id===s.id).map(m=>({id:m.id,name:m.title||m.name||'ملف PDF',link:m.drive_web_view_url||m.drive_url||'#'}))}))}))}));return {tree};}
  async function createMaterialFolder(semesterId,name,departmentId){const subjects=await req('/admin/subjects?limit=100');const dep=departmentId||subjects.find(x=>x.semester_id===semesterId)?.department_id;if(!dep)throw new Error('اختر القسم أولاً.');return req('/admin/subjects',{method:'POST',body:JSON.stringify({semester_id:semesterId,department_id:dep,name_ar:name,name_en:name,active:1,sort_order:0})});}
  async function renameMaterialItem(){throw new Error('تعديل ملفات Drive المباشر غير مفعّل في هذه المرحلة. استخدم المزامنة الآمنة.');} async function deleteMaterialItem(id){return req('/admin/materials/'+id,{method:'DELETE'});} async function deleteSubject(id){return req('/admin/subjects/'+id,{method:'DELETE'});} async function uploadMaterialPdf(){throw new Error('رفع ملفات Drive المباشر غير مفعّل في هذه المرحلة.');}
  async function getSiteSettings(){const rows=await req('/admin/settings');const o={};for(const r of rows){try{o[r.key]=JSON.parse(r.value_json);}catch{o[r.key]=r.value_json;}}return o;}
  async function updateSiteSettings(fields,logoFile=null){
    const payload={...(fields||{})}; delete payload._LogoFile;
    if(logoFile){const uploaded=await uploadMedia(logoFile); payload.Logo=uploaded.url;}
    for(const [key,value] of Object.entries(payload)) await req('/admin/settings/'+encodeURIComponent(key),{method:'PATCH',body:JSON.stringify({key,value})});
    return {success:true};
  }
  async function listUsers(){return (await req('/admin/staff')).map(r=>({id:r.id,fields:{Names:r.display_name,Username:r.user_id,Email:r.email||'',Role:roleLabel(r.role_id),RoleId:r.role_id,Active:!!r.active,LastLogin:r.last_login_at}}));}
  const ROLE_IDS={
    'مدير عام':'super_admin',
    'محرر محتوى':'content_manager',
    'مسؤول أكاديمي':'academic_manager',
    super_admin:'super_admin',content_manager:'content_manager',academic_manager:'academic_manager',moderator:'moderator', 'مشرف':'moderator'
  };
  // Content editor schemas. Keep these definitions in the adapter so the admin UI
  // cannot start with an undefined `schemas` object (which previously broke the
  // content editor before image fields could be uploaded to R2).
  const schemas = {
    news: {
      label: 'خبر', labelPlural: 'الأخبار',
      fields: [
        {key:'Title', label:'العنوان', type:'text', required:true},
        {key:'Content', label:'المحتوى', type:'textarea', required:true},
        {key:'Category', label:'التصنيف', type:'text'},
        {key:'Publisher', label:'الناشر', type:'text'},
        {key:'Date', label:'تاريخ النشر', type:'date'},
        {key:'Image', label:'صورة الخبر', type:'image'}
      ]
    },
    events: {
      label: 'فعالية', labelPlural: 'الفعاليات',
      fields: [
        {key:'Title', label:'العنوان', type:'text', required:true},
        {key:'Content', label:'المحتوى', type:'textarea', required:true},
        {key:'Category', label:'التصنيف', type:'text'},
        {key:'Location', label:'المكان', type:'text'},
        {key:'Publisher', label:'الناشر', type:'text'},
        {key:'Date', label:'تاريخ الفعالية', type:'date'},
        {key:'EndDate', label:'تاريخ الانتهاء', type:'date'},
        {key:'Image', label:'صورة الفعالية', type:'image'}
      ]
    },
    announcements: {
      label: 'إشعار', labelPlural: 'الإشعارات',
      fields: [
        {key:'Title', label:'العنوان', type:'text', required:true},
        {key:'Content', label:'المحتوى', type:'textarea', required:true},
        {key:'Type', label:'النوع', type:'select', options:[{value:'general',label:'عام'},{value:'urgent',label:'عاجل'}], default:'general'},
        {key:'DepartmentId', label:'القسم المستهدف', type:'text'},
        {key:'SemesterId', label:'الفصل المستهدف', type:'text'},
        {key:'Date', label:'تاريخ النشر', type:'date'},
        {key:'ExpiresAt', label:'تاريخ الانتهاء', type:'date'}
      ]
    },
    achievements: {
      label: 'إنجاز', labelPlural: 'الإنجازات',
      fields: [
        {key:'Title', label:'العنوان', type:'text', required:true},
        {key:'Intro', label:'المقدمة', type:'textarea'},
        {key:'HighlightsTitle', label:'عنوان المحاور', type:'text'},
        {key:'Highlights', label:'المحاور', type:'highlights'},
        {key:'Badge', label:'الشارة', type:'text'},
        {key:'Publisher', label:'الناشر', type:'text'},
        {key:'PublishDate', label:'تاريخ الإنجاز', type:'date'},
        {key:'Image', label:'صور الإنجاز', type:'images'}
      ]
    }
  };

  const ROLE_BADGE={super_admin:'badge-danger',content_manager:'badge-info',academic_manager:'badge-success',moderator:'badge-warning'};
  const ROLE_LABEL={super_admin:'مدير عام',content_manager:'محرر محتوى',academic_manager:'مسؤول أكاديمي',moderator:'مشرف'};
  function roleId(value){return ROLE_IDS[value]||value||'content_manager';}
  function roleLabel(value){return ROLE_LABEL[value]||value||'—';}
  async function createUser(f){return req('/admin/staff',{method:'POST',body:JSON.stringify({userId:f.Username, email:f.Email||null, displayName:f.Names,roleId:roleId(f.Role),password:f.Password})});}
  async function updateUser(id,f){return req('/admin/staff/'+id,{method:'PATCH',body:JSON.stringify({userId:f.Username, email:f.Email===undefined?undefined:(f.Email||null),displayName:f.Names,roleId:roleId(f.Role),active:f.Active,password:f.Password||undefined})});}
  async function toggleUserActive(id){const users=await listUsers(),u=users.find(x=>x.id===id);return updateUser(id,{Names:u.fields.Names,Username:u.fields.Username,Role:u.fields.RoleId||u.fields.Role,Active:!u.fields.Active});} async function deleteUser(id){return req('/admin/staff/'+id,{method:'DELETE'});}
  async function listModerationComments(status='visible'){return req('/admin/moderation/comments?status='+encodeURIComponent(status)+'&limit=100');}
  async function moderateComment(id,status){return req('/admin/moderation/comments/'+encodeURIComponent(id),{method:'PATCH',body:JSON.stringify({status})});} async function deleteCommentAdmin(id){return req('/admin/comments/'+encodeURIComponent(id),{method:'DELETE'});}
  async function listAuditLog(){return (await req('/admin/audit-logs')).map(r=>({id:r.id,fields:{Timestamp:r.created_at,User:r.actor_name||r.actor_id||'',Role:r.role_name||'',Action:r.action,Details:r.resource_type+(r.resource_id?': '+r.resource_id:'')}}));}
  async function listFailedLoginAttempts(){return (await req('/admin/security/auth-events?limit=50')).map(r=>({id:r.id,fields:{Timestamp:r.created_at,User:r.actor_name||r.actor_user_id||r.actor_email||r.actor_id||'',Role:r.role_name||'',Action:r.event_type,Details:r.event_type}}));}
  async function changePassword(oldPassword,newPassword){return req('/auth/staff/change-password',{method:'POST',body:JSON.stringify({currentPassword:oldPassword,newPassword})});}
  async function login(userId,password){const d=await req('/auth/staff/login',{method:'POST',headers:{},body:JSON.stringify({userId,password})});return {token:d.token,refreshToken:d.refreshToken,name:d.staffDisplayName||userId,role:d.staffRole||d.role_name||d.staffRoleId,expiresAt:Date.now()+((d.expiresInSeconds||900)*1000)};}
  async function logoutSession(t){try{await fetch(base()+'/auth/logout',{method:'POST',headers:{Authorization:'Bearer '+t}});}catch{}}
  async function getOverviewStats(){return req('/admin/dashboard/overview');}
  async function getEinoUsage(hours=24){return req('/admin/security/eino-usage?hours='+encodeURIComponent(Math.min(168,Math.max(1,Number(hours)||24))));} async function getRecentNews(l){return (await listContent('news')).slice(0,l||5).map(r=>({id:r.id,title:r.fields.Title,date:r.fields.Date,views:0}));} async function getSystemHealth(){try{await req('/health');return [{name:'Association API',configured:true,lastSuccess:new Date().toISOString()}];}catch{return [{name:'Association API',configured:true,lastSuccess:null}];}}
  return {CONTENT_TYPES:schemas,getContentSchema:t=>schemas[t],listContent,createContent,updateContent,deleteContent,listStudentsAdmin,createStudentAdmin,updateStudentAdmin,deleteStudentAdmin,toggleStudentAdmin,listScheduleAdmin,createScheduleEntry,updateScheduleEntry,deleteScheduleEntry,toggleScheduleEntry,listMaterialsAdmin,syncDriveMaterials,createMaterialFolder,renameMaterialItem,deleteMaterialItem,deleteSubject,uploadMaterialPdf,getSiteSettings,updateSiteSettings,listUsers,createUser,updateUser,toggleUserActive,deleteUser,listAuditLog,listFailedLoginAttempts,listModerationComments,moderateComment,deleteCommentAdmin,changePassword,login,logoutSession,getOverviewStats,getEinoUsage,getRecentNews,getSystemHealth,sendNotification,listNotifications,ROLE_BADGE};
})();
