import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/localization/app_localizations.dart';
import '../../core/theme/design_tokens.dart';
import '../../features/eino/eino_face.dart';

class TrinexShell extends StatefulWidget {
  const TrinexShell({
    required this.location,
    required this.child,
    super.key,
  });

  final String location;
  final Widget child;

  @override
  State<TrinexShell> createState() => _TrinexShellState();
}

class _TrinexShellState extends State<TrinexShell>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulse = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 3),
  )..repeat();

  bool _einoVisible = false;

  bool get _readingMode =>
      widget.location == '/media/detail' || widget.location == '/news/detail';

  @override
  void initState() {
    super.initState();
    _einoVisible = !_readingMode;
    FocusManager.instance.addListener(_handleFocusChange);
  }

  @override
  void didUpdateWidget(covariant TrinexShell oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.location != widget.location && _readingMode) {
      _einoVisible = false;
    } else if (oldWidget.location != widget.location && !_readingMode) {
      _einoVisible = true;
    }
  }

  void _handleFocusChange() {
    final focusContext = FocusManager.instance.primaryFocus?.context;
    final isEditing =
        focusContext?.findAncestorWidgetOfExactType<EditableText>() != null;
    if (!mounted) return;
    if (isEditing && _einoVisible) {
      setState(() => _einoVisible = false);
    } else if (!isEditing && !_einoVisible && !_readingMode) {
      setState(() => _einoVisible = true);
    }
  }

  @override
  void dispose() {
    FocusManager.instance.removeListener(_handleFocusChange);
    _pulse.dispose();
    super.dispose();
  }

  int get index {
    if (widget.location.startsWith('/home')) return 0;
    if (widget.location.startsWith('/system')) return 1;
    if (widget.location.startsWith('/schedule')) return 2;
    if (widget.location.startsWith('/materials')) return 3;
    return 4;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            const _TopHeader(),
            Expanded(
              child: Stack(
                children: [
                  LayoutBuilder(
                    builder: (context, constraints) {
                      final maxWidth = constraints.maxWidth >= 1100 ? 1040.0 : constraints.maxWidth;
                      return Align(
                        alignment: Alignment.topCenter,
                        child: ConstrainedBox(
                          constraints: BoxConstraints(maxWidth: maxWidth),
                          child: widget.child,
                        ),
                      );
                    },
                  ),
                  if (_einoVisible)
                    PositionedDirectional(
                      end: 16,
                      bottom: 18,
                      child: EinoFloatingButton(animation: _pulse),
                    ),
                  // A narrow edge gesture lets the student summon Eino again
                  // without adding another permanent button to the UI.
                  PositionedDirectional(
                    start: 0,
                    top: 0,
                    bottom: 0,
                    width: 24,
                    child: GestureDetector(
                      behavior: HitTestBehavior.translucent,
                      onHorizontalDragEnd: (details) {
                        final rtl = Directionality.of(context) == TextDirection.rtl;
                        final velocity = details.primaryVelocity ?? 0;
                        final summoned = rtl ? velocity < -350 : velocity > 350;
                        if (summoned && !_einoVisible && mounted) {
                          setState(() => _einoVisible = true);
                        }
                      },
                    ),
                  ),
                ],
              ),
            ),
            _MainNav(selected: index),
            const SizedBox(height: 4),
          ],
        ),
      ),
    );
  }
}

class _TopHeader extends StatelessWidget {
  const _TopHeader();

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return Container(
      height: 68,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor.withValues(alpha: .96),
        border: Border(
          bottom: BorderSide(color: context.colors.outlineVariant.withValues(alpha: .62)),
        ),
      ),
      child: LayoutBuilder(
        builder: (context, box) {
          final compact = box.maxWidth < 600;
          final button = compact ? 48.0 : 52.0;
          final avatar = compact ? 42.0 : 46.0;
          final logo = compact ? 48.0 : 52.0;
          final primary = context.colors.primary;

          // The header is intentionally LTR so its physical layout stays
          // consistent in the Arabic UI:
          // left  -> TRINEX + app icon (app icon opens Settings)
          // right -> profile + System
          return Directionality(
            textDirection: TextDirection.ltr,
            child: Row(
              children: [
                // Left side: tappable application icon + brand name.
                Material(
                  color: Colors.transparent,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(DesignTokens.radius12),
                    onTap: () => context.push('/settings'),
                    child: Tooltip(
                      message: l10n.t('settings'),
                      child: Container(
                        width: logo,
                        height: logo,
                        padding: const EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          color: primary,
                          borderRadius: BorderRadius.circular(DesignTokens.radius14),
                          boxShadow: [
                            BoxShadow(
                              color: primary.withValues(alpha: .18),
                              blurRadius: 12,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Image.asset(
                          'assets/icons/trinex_icon.png',
                          fit: BoxFit.contain,
                          filterQuality: FilterQuality.high,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 9),
                Text(
                  'TRINEX',
                  style: TextStyle(
                    fontSize: compact ? 18 : 20,
                    fontWeight: FontWeight.w900,
                    letterSpacing: .3,
                  ),
                ),
                const Spacer(),
                // Right side: System page + profile, so profile is physically
                // on the far right while System sits immediately to its left.
                _HeaderIcon(
                  icon: Icons.notifications_none_rounded,
                  size: button,
                  tooltip: l10n.t('notifications'),
                  onTap: () => context.push('/notifications'),
                ),
                const SizedBox(width: 2),
                _HeaderIcon(
                  icon: Icons.workspace_premium_outlined,
                  size: button,
                  tooltip: l10n.t('navSystem'),
                  onTap: () => context.go('/system'),
                ),
                const SizedBox(width: 4),
                _Avatar(
                  size: avatar,
                  onTap: () => context.go('/student'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _MainNav extends StatelessWidget {
  const _MainNav({required this.selected});

  final int selected;

  static const items = [
    ('navHome', Icons.home_outlined, '/home'),
    ('navSystem', Icons.workspace_premium_outlined, '/system'),
    ('navSchedule', Icons.calendar_month_outlined, '/schedule'),
    ('navMaterials', Icons.menu_book_outlined, '/materials'),
    ('navMore', Icons.grid_view_rounded, '/more'),
  ];

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 6, 10, 8),
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: context.colors.surface,
          borderRadius: BorderRadius.circular(DesignTokens.radius20),
          border: Border.all(color: context.colors.outlineVariant.withValues(alpha: .72)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: Theme.of(context).brightness == Brightness.dark ? .16 : .06),
              blurRadius: 18,
              offset: const Offset(0, -4),
            ),
          ],
        ),
        child: NavigationBar(
          selectedIndex: selected.clamp(0, items.length - 1),
          height: 68,
          backgroundColor: Colors.transparent,
          surfaceTintColor: Colors.transparent,
          elevation: 0,
          indicatorColor: context.colors.primaryContainer,
          labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
          onDestinationSelected: (i) => context.go(items[i].$3),
          destinations: [
            for (final item in items)
              NavigationDestination(
                icon: Icon(item.$2),
                selectedIcon: Icon(item.$2),
                label: l10n.t(item.$1),
              ),
          ],
        ),
      ),
    );
  }
}

class _HeaderIcon extends StatelessWidget {
  const _HeaderIcon({
    required this.icon,
    required this.tooltip,
    this.onTap,
    this.size = 48,
  });

  final IconData icon;
  final String tooltip;
  final VoidCallback? onTap;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(DesignTokens.radius12),
          onTap: onTap,
          child: SizedBox(
            width: size,
            height: size,
            child: Icon(
              icon,
              color: context.colors.onSurface,
              size: 23,
            ),
          ),
        ),
      ),
    );
  }
}

class _Avatar extends StatelessWidget {
  const _Avatar({this.size = 50, this.onTap});

  final double size;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    return Tooltip(
      message: l10n.t('profile'),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(size),
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: context.colors.surfaceContainerHigh,
            border: Border.all(
              color: context.colors.outlineVariant,
              width: 1.2,
            ),
          ),
          child: Icon(
            Icons.account_circle_rounded,
            color: context.colors.primary,
            size: size * .84,
          ),
        ),
      ),
    );
  }
}

class EinoFloatingButton extends StatelessWidget {
  const EinoFloatingButton({required this.animation, super.key});

  final Animation<double> animation;

  @override
  Widget build(BuildContext context) {
    final primary = context.colors.primary;
    return AnimatedBuilder(
      animation: animation,
      builder: (context, _) {
        final glow =
            .12 + (.10 * (0.5 + 0.5 * (animation.value * 2 - 1).abs()));
        return Semantics(
          button: true,
          label: 'Eino',
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: () => context.push('/eino?from=shell'),
              borderRadius: BorderRadius.circular(34),
              child: Container(
                width: 68,
                height: 68,
                padding: const EdgeInsets.all(2.5),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: context.colors.surface,
                  border: Border.all(
                    color: context.colors.primary,
                    width: 2.2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: primary.withValues(alpha: glow),
                      blurRadius: 12,
                    ),
                  ],
                ),
                child: const EinoFace(
                  size: 76,
                  mood: EinoMood.happy,
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
